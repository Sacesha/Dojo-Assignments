function logout() {
    document.getElementById("lb").innerText = "Logout";
}
function addLikes() {
    alert('Ninja was liked');
}
function remove() {
    document.getElementById("add").style.display = 'none'
}